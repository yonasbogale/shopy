export const SIGNUP = 'SIGNUP';
export const LOGIN = 'LOGIN';
export const LOCAL_LOGIN = 'LOCAL_LOGIN';
export const LOGOUT = 'LOGOUT';
