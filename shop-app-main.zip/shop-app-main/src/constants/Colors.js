export const Colors = {
  background: '248,248,255',
  primary: '79, 60, 230',
  primaryDark: '0, 0, 41',
  primaryDarker: '15, 5, 33',
  card: '253, 253, 255',
  accent: '255, 193, 7',
  accentTwo: '20, 163, 101',
  danger: '224, 67, 78',
  warning: '255,174,66',
  text: {
    primary: '15, 5, 33',
    secondary: '149, 154, 156',
  },
};
